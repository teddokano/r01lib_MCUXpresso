/** test code for r01lib
 *
 *  @author Tedd OKANO
 *
 *  Released under the MIT license
 */

#include	"r01lib.h"
#include	<math.h>

int main( void )
{
	printf( "Hello, world!\r\n" );
	printf( "test for float print: %f\r\n", M_PI );
	printf( "test for utf-8 print: %s\r\n", "℃" );

	return 0;
}
