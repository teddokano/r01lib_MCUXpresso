var searchData=
[
  ['freq_0',['FREQ',['../class_i2_c.html#aa009bd9217f2fe39b32a96aa68125edd',1,'I2C::FREQ'],['../class_i3_c.html#ac4c6baa4f489f1a470b86ad579fb0107',1,'I3C::FREQ']]]
];
