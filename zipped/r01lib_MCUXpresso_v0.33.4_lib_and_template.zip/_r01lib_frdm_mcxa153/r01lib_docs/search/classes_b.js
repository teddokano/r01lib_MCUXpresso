var searchData=
[
  ['serial_5fdevice_0',['Serial_device',['../class_serial__device.html',1,'']]],
  ['spi_1',['SPI',['../class_s_p_i.html',1,'']]],
  ['spi_5ffor_5fafe_2',['SPI_for_AFE',['../class_s_p_i__for___a_f_e.html',1,'']]],
  ['spi_5ffor_5frtc_3',['SPI_for_RTC',['../class_s_p_i__for___r_t_c.html',1,'']]]
];
