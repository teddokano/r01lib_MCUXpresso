var searchData=
[
  ['vendor_5fid_5fregister_0',['Vendor_ID_Register',['../class_p_c_f85053_a.html#ab7f4ad9c87ac514866160f256eb7af1ea5e0c7572d2ca81420ab4f640386cf963',1,'PCF85053A']]],
  ['version_5fregister_1',['Version_Register',['../class_p_c_f85053_a.html#ab7f4ad9c87ac514866160f256eb7af1ea2db4461115915f43d9fd7475e6f4e074',1,'PCF85053A']]]
];
