var searchData=
[
  ['stop_5fcondition_0',['STOP_CONDITION',['../class_i2_c.html#a16f825cf263a78a1c983da06506763f2',1,'I2C']]]
];
