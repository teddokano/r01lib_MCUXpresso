var searchData=
[
  ['timestanp_5fsetting_0',['timestanp_setting',['../class_p_c_f2131.html#a406a44b72f3996bf10c760e745408840',1,'PCF2131']]],
  ['ts_5fin_1',['ts_in',['../class_p_c_f85263_a.html#a5a002fd033a255abadc485673a13f632',1,'PCF85263A']]]
];
