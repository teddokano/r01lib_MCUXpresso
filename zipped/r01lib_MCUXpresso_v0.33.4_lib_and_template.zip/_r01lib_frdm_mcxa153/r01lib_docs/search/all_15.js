var searchData=
[
  ['xfer_0',['xfer',['../class_i3_c.html#a7081b70e0c4702e5193b64fdbd144ce2',1,'I3C']]]
];
