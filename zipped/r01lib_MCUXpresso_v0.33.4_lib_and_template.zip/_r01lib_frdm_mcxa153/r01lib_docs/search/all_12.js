var searchData=
[
  ['unit_5fbase_0',['unit_base',['../class_i2_c.html#a6c44b9051a72a4a0c339256f336a2cd9',1,'I2C']]],
  ['utick_5ftype_1',['utick_type',['../class_ticker.html#a887d2a6eef5b3f51fae8fbc448a01b1f',1,'Ticker']]]
];
