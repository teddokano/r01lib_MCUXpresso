var searchData=
[
  ['ibi_5fpayload_5fbuffer_5fsize_0',['IBI_PAYLOAD_BUFFER_SIZE',['../i3c_8cpp.html#a039307005eb408df115b1aef7055ba21',1,'i3c.cpp']]]
];
