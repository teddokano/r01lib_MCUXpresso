var searchData=
[
  ['spi_5ffreq_0',['SPI_FREQ',['../spi_8h.html#a6254a4e77c7f2f980d5f49538893d0ab',1,'spi.h']]]
];
