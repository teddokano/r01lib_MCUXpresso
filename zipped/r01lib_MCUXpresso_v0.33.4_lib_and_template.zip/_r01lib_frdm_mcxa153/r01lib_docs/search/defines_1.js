var searchData=
[
  ['custom_5fregistar_5fxfer_0',['CUSTOM_REGISTAR_XFER',['../i3c_8h.html#a1890ecd35abcfe4c4029772fd92711d9',1,'i3c.h']]]
];
