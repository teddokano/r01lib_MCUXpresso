var searchData=
[
  ['read_5fbuffer_5fsize_0',['READ_BUFFER_SIZE',['../_s_p_i__for___a_f_e_8cpp.html#a46167a977503a51eb6efe97e870568c3',1,'SPI_for_AFE.cpp']]],
  ['reg_5frw_5fbuffer_5fsize_1',['REG_RW_BUFFER_SIZE',['../i2c_8h.html#a63640d65f31c8e50210e961ffbcfe7fd',1,'i2c.h']]]
];
