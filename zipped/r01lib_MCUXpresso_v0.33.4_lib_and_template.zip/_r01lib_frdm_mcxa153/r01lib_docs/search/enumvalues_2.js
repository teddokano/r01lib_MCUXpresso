var searchData=
[
  ['battery_5fswitch_0',['Battery_switch',['../class_p_c_f85263_a.html#aa8b27745f67151341314514efb025411a0764b94db6f316086be4f6e2de619993',1,'PCF85263A']]],
  ['broadcast_5faddr_1',['BROADCAST_ADDR',['../class_i3_c.html#a2fe3725df0ba7782c7b1d9059c75ff17ae20dc44b3a55bd52b5786ce9015179fa',1,'I3C']]],
  ['broadcast_5fenec_2',['BROADCAST_ENEC',['../i3c_8h.html#acba81d13b8fe4dc120a844ff5fb37321a01a567e962f715d42b9f8a47e3b3aedc',1,'i3c.h']]],
  ['broadcast_5fentdaa_3',['BROADCAST_ENTDAA',['../i3c_8h.html#acba81d13b8fe4dc120a844ff5fb37321a7112cc447056721f3b0447d61a288ef9',1,'i3c.h']]],
  ['broadcast_5frstdaa_4',['BROADCAST_RSTDAA',['../i3c_8h.html#acba81d13b8fe4dc120a844ff5fb37321a2e90424598dd58e7b33ab74abb5009cf',1,'i3c.h']]]
];
